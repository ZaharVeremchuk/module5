with open("raw_data.bin", "wb") as fh:
    fh.write(b'Write like bytes')