with open("test.txt", "r", encoding="utf-8") as fh:
    content = fh.read()
    print(content)