with open("test.txt", "w") as fh:
    fh.write("Some data")
    # Automaticly close file