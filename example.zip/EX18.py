# For comparing string similar to lower() but more radial
text = "Python Programing"
print(text.casefold())