fh = open('test.txt')
fh.close()